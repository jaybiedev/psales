 <script>
 function vComputeSalary()
 {
 	document.getElementById('f1').adwr.value = twoDecimals((document.getElementById('ratem').value*12)/365);
 	document.getElementById('f1').hourly.value = twoDecimals(document.getElementById('adwr').value/8);
 }
 </script> 
  
<table width="100%" border="0" align="center" cellpadding="1" cellspacing="1" bgcolor="#FFFFFF">
  <tr bgcolor="#EFEFEF"> 
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Employment 
      Status</font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
      <?= lookUpAssoc('emp_status',array('Active'=>'1','Resigned'=>'2','Retired'=>'3','In Active'=>'4','AWOL'=>'5','Casual'=>'6'),$paymast['emp_status']);?>
      </font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Date Employed 
      </font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
      <input name="date_employ" type="text" id="date_employ" value="<?= ymd2mdy($paymast['date_employ']);?>" size="12" onBlur="IsValidDate(this,'MM/dd/yyyy')" onKeyUp="setDate(this,'MM/dd/yyyy','en')"  onKeypress="if(event.keyCode==13) {document.getElementById('remarks').focus();return false;}">
      <img src="../graphics/dwn-arrow-grn.gif" width="12" height="12" onClick="popUpCalendar(this, f1.date_employ, 'mm/dd/yyyy')"> 
      </font><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
      </font></td>
  </tr>
  <tr bgcolor="#EFEFEF"> 
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Branch</font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
      <?= lookUpTable2('branch_id','branch','branch_id','branch',$paymast['branch_id']);?>
      </font></td>
    <td>&nbsp;</td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; </font></td>
  </tr>
  <tr bgcolor="#EFEFEF"> 
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Department</font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
      <?= lookUpTable2('department_id','department','department_id','department',$paymast['department_id']);?>
      </font></td>
    <td>&nbsp;</td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; </font></td>
  </tr>
  <tr bgcolor="#EFEFEF"> 
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Section</font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
      <?= lookUpTable2('section_id','section','section_id','section',$paymast['section_id']);?>
      </font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Employment 
      Level</font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
      <?= lookUpTable2('level_id','level','level_id','level',$paymast['level_id']);?>
      </font></td>
  </tr>
  <tr bgcolor="#EFEFEF"> 
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Postition</font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
      <input name="position" type="text" id="position" value="<?= $paymast['position'];?>" size="30">
      </font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Tenure Allowance</font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
      <input name="tenureallowance" type="text" id="tenureallowance" value="<?= $paymast['tenureallowance'];?>" size="15" style="text-align:right">
      <?= lookUpAssoc("tenurew",array("None"=>'0',"Daily"=>"D","Monthly"=>"M"),$paymast['tenurew']);?>
      </font></td>
  </tr>
  <tr bgcolor="#EFEFEF"> 
    <td valign="top"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Rank</font></td>
    <td><?= lookUpAssoc('rank',array('Rank & File'=>'R', 'Supervisor'=>'S'), $paymast['rank']);?></td>
    <td colspan="2" valign="top">&nbsp;</td>
  </tr>
  <tr bgcolor="#EFEFEF"> 
    <td>&nbsp;</td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; </font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Pay Category 
      </font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
      <?= lookUpAssoc('pay_category',array('Regular Monthly'=>'1','Regular Daily'=>'2','ProB Monthly'=>'3','ProB Daily'=>'4','Contractual'=>'5','Daily Casual'=>'6'),$paymast['pay_category']);?>
      </font></td>
  </tr>
  <tr bgcolor="#EFEFEF"> 
    <td>&nbsp;</td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; </font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Monthly Rate</font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
      <input name="ratem" type="text" id="ratem" value="<?= $paymast['ratem'];?>" size="15" onBlur="vComputeSalary()" style="text-align:right">
      </font></td>
  </tr>
  <tr bgcolor="#EFEFEF"> 
    <td>&nbsp;</td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; </font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Average Daily 
      Wage</font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
      <input name="adwr" type="text" id="adwr" value="<?= $paymast['adwr'];?>" size="15" style="text-align:right">
      </font></td>
  </tr>
  <tr bgcolor="#EFEFEF"> 
    <td>&nbsp;</td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; </font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Hourly Rate</font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
      <input name="hourly" type="text" id="hourly" value="<?= $paymast['hourly'];?>" size="15"  style="text-align:right">
      </font></td>
  </tr>
  <tr bgcolor="#EFEFEF"> 
    <td valign="top">&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="2" valign="top">&nbsp;</td>
  </tr>
</table>
