 <div id='payroll_summary' style='position:absolute; width:100%; height:100%; z-index:1; overflow: auto; background-color: #FFFFFF; layer-background-color: #FFFFFF; border: 1px none #000000; visibility: hidden;'>
   <table width="100%" height="100%" border="1" cellpadding="0" cellspacing="1" bordercolor="#000033">
      <tr   height="100%"> 
		<td>
		</td>
    </tr>
 
    </table>
</div>	