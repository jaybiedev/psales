 <div id="payroll_payroll" style="position:absolute; width:90%; height:115px; z-index:3; visibility: hidden;">
    <table width="95%" border="0" align="center" cellpadding="1" cellspacing="1" bgcolor="#FFFFFF">
      <tr bgcolor="#E2E2E2"> 
        <td colspan="7" bgcolor="#CCCCCC"><strong><font size="3" face="Verdana, Arial, Helvetica, sans-serif">Payroll 
          History</font></strong></td>
      </tr>
      <tr bgcolor="#E2E2E2"> 
        <td bgcolor="#E2E2E2"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Period</font></strong></td>
        <td bgcolor="#E2E2E2"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Basic</font></strong></td>
        <td bgcolor="#E2E2E2"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Net 
          Income</font></strong></td>
        <td bgcolor="#E2E2E2"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">SSS</font></strong></td>
        <td bgcolor="#E2E2E2"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">PHIC</font></strong></td>
        <td bgcolor="#E2E2E2"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Tax</font></strong></td>
        <td bgcolor="#E2E2E2"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
          PagIbig</font></strong></td>
      </tr>
      <tr bgcolor="#E2E2E2"> 
        <td bgcolor="#EFEFEF"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
        <td bgcolor="#EFEFEF"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
        <td bgcolor="#EFEFEF"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
        <td bgcolor="#EFEFEF"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
        <td bgcolor="#EFEFEF"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
        <td bgcolor="#EFEFEF"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
        <td bgcolor="#EFEFEF"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
      </tr>
    </table>
  </div>
