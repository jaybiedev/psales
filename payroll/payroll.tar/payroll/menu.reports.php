<div align="center">
  <p>&nbsp;</p>
  <p><font color="#000000" size="4" face="Times New Roman, Times, serif">Menu 
    Reports</font> </p>
  <hr width="50%" size="1">
</div>
<table width="1%" border="0" align="center" cellpadding="2" cellspacing="1">
  <tr> 
    <td><img src="../graphics/list3.gif" width="16" height="16"></td>
    <td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="?p=report.stockmovement">Stocks 
      Movement</a></font></td>
  </tr>
  <tr> 
    <td><img src="../graphics/list3.gif" width="16" height="16"></td>
    <td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="?p=report.dailysales">Daily 
      Sales Report</a></font></td>
  </tr>
  <tr> 
    <td><img src="../graphics/list3.gif" width="16" height="16"></td>
    <td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="?p=report.periodicsales">Periodic 
      Sales</a></font></td>
  </tr>
  <tr> 
    <td height="23"><img src="../graphics/list3.gif" width="16" height="16"></td>
    <td height="23" nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="?p=report.grossprofit">Gross 
      Profit/Loss</a></font></td>
  </tr>
</table>
