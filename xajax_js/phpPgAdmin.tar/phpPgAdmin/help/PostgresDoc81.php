<?php

/**
 * Help links for PostgreSQL 8.1 documentation
 *
 * $Id: PostgresDoc81.php,v 1.1 2005/03/15 02:44:11 chriskl Exp $
 */

include('./help/PostgresDoc80.php');

$this->help_base = sprintf($GLOBALS['conf']['help_base'], '8.1');

?>
