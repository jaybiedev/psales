<?php

/**
 * Help links for PostgreSQL 8.2 documentation
 *
 * $Id: PostgresDoc82.php,v 1.1 2005/11/08 02:24:31 chriskl Exp $
 */

include('./help/PostgresDoc81.php');

$this->help_base = sprintf($GLOBALS['conf']['help_base'], '8.2');

?>
